INSERT INTO `vorp`.`items`(`item`, `label`, `limit`, `can_remove`, `type`, `usable`) VALUES ('a_c_fishbluegil_01_ms', 'Pez sol mediano', 3, 1, 'item_standard', 0);
INSERT INTO `vorp`.`items`(`item`, `label`, `limit`, `can_remove`, `type`, `usable`) VALUES ('a_c_fishbluegil_01_sm', 'Pez sol pequeño', 5, 1, 'item_standard', 0);
INSERT INTO `vorp`.`items`(`item`, `label`, `limit`, `can_remove`, `type`, `usable`) VALUES ('a_c_fishbullheadcat_01_ms', 'Bagre cabeza de toro mediano', 3, 1, 'item_standard', 0);
INSERT INTO `vorp`.`items`(`item`, `label`, `limit`, `can_remove`, `type`, `usable`) VALUES ('a_c_fishbullheadcat_01_sm', 'Bagre cabeza de toro pequeño', 5, 1, 'item_standard', 0);
INSERT INTO `vorp`.`items`(`item`, `label`, `limit`, `can_remove`, `type`, `usable`) VALUES ('a_c_fishchainpickerel_01_ms', 'Lucio cadena mediano', 3, 1, 'item_standard', 0);
INSERT INTO `vorp`.`items`(`item`, `label`, `limit`, `can_remove`, `type`, `usable`) VALUES ('a_c_fishchainpickerel_01_sm', 'Lucio cadena pequeño', 5, 1, 'item_standard', 0);
INSERT INTO `vorp`.`items`(`item`, `label`, `limit`, `can_remove`, `type`, `usable`) VALUES ('a_c_fishlargemouthbass_01_ms', 'Perca americana', 3, 1, 'item_standard', 0);
INSERT INTO `vorp`.`items`(`item`, `label`, `limit`, `can_remove`, `type`, `usable`) VALUES ('a_c_fishperch_01_ms', 'Perca mediana', 3, 1, 'item_standard', 0);
INSERT INTO `vorp`.`items`(`item`, `label`, `limit`, `can_remove`, `type`, `usable`) VALUES ('a_c_fishperch_01_sm', 'Perca pequeña', 5, 1, 'item_standard', 0);
INSERT INTO `vorp`.`items`(`item`, `label`, `limit`, `can_remove`, `type`, `usable`) VALUES ('a_c_fishrainbowtrout_01_ms', 'Trucha cabeza de acero', 3, 1, 'item_standard', 0);
INSERT INTO `vorp`.`items`(`item`, `label`, `limit`, `can_remove`, `type`, `usable`) VALUES ('a_c_fishredfinpickerel_01_ms', 'Lucio americano de aleta roja mediano', 3, 1, 'item_standard', 0);
INSERT INTO `vorp`.`items`(`item`, `label`, `limit`, `can_remove`, `type`, `usable`) VALUES ('a_c_fishredfinpickerel_01_sm', 'Lucio americano de aleta roja pequeño', 5, 1, 'item_standard', 0);
INSERT INTO `vorp`.`items`(`item`, `label`, `limit`, `can_remove`, `type`, `usable`) VALUES ('a_c_fishrockbass_01_ms', 'Lubina de roca mediana', 3, 1, 'item_standard', 0);
INSERT INTO `vorp`.`items`(`item`, `label`, `limit`, `can_remove`, `type`, `usable`) VALUES ('a_c_fishrockbass_01_sm', 'Lubina de roca pequeña', 5, 1, 'item_standard', 0);
INSERT INTO `vorp`.`items`(`item`, `label`, `limit`, `can_remove`, `type`, `usable`) VALUES ('a_c_fishsalmonsockeye_01_ms', 'Salmón rojo', 3, 1, 'item_standard', 0);
INSERT INTO `vorp`.`items`(`item`, `label`, `limit`, `can_remove`, `type`, `usable`) VALUES ('a_c_fishsmallmouthbass_01_ms', 'Lubina de boca pequeña', 3, 1, 'item_standard', 0);


INSERT INTO `vorp`.`items`(`item`, `label`, `limit`, `can_remove`, `type`, `usable`) VALUES ('fishbait', 'Cebo', 10, 1, 'item_standard', 0);